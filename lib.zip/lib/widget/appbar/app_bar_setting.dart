import 'package:dr_urticaria/utils/common_app.dart';
import 'package:flutter/material.dart';

class AppBarSetting {
  static Color iconAndTextColor = colorApp.black;
}
