/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: directives_ordering,unnecessary_import,implicit_dynamic_list_literal,deprecated_member_use

class FontFamily {
  FontFamily._();

  /// Font family: Inter
  static const String inter = 'Inter';

  /// Font family: InterBlack
  static const String interBlack = 'InterBlack';

  /// Font family: InterBold
  static const String interBold = 'InterBold';

  /// Font family: InterExtraBold
  static const String interExtraBold = 'InterExtraBold';

  /// Font family: InterExtraLight
  static const String interExtraLight = 'InterExtraLight';

  /// Font family: InterLight
  static const String interLight = 'InterLight';

  /// Font family: InterMedium
  static const String interMedium = 'InterMedium';

  /// Font family: InterRegular
  static const String interRegular = 'InterRegular';

  /// Font family: InterSemiBold
  static const String interSemiBold = 'InterSemiBold';

  /// Font family: InterThin
  static const String interThin = 'InterThin';

  /// Font family: Sans
  static const String sans = 'Sans';
}
